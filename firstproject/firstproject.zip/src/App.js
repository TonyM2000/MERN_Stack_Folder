function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>
          Hello Dojo!
        </h1>
        <h2>
          Things I Need to Do:
        </h2>
        <p>
          *Learn React
        </p>
        <p>
          *Climb mount everest
        </p>
        <p>
          *Run a marathon
        </p>
        <p>
          *Feed the dogs
        </p>
      </header>
    </div>
  );
}

export default App;
